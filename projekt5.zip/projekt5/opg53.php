<?php

//$random = rand(1,20);
$tal = [100,200,300,400];

//function arr_merge($v1, $v2) {
    //$r = $v1 + $v2;
    //return $r;
//}




//$nytal = arr_merge($arr + $tal);
//echo $nytal;

//ho sort($nytal);

function mix($tal) {
//$random = rand(1, 20);
    //$tal = [0, 3, 6, 7, 8, 11, 14, 16, 21];
    $min = $tal[0];
    $max=$tal[count($tal)-1];
    $nyttal = true;
    while ($nyttal) {
       echo $random = rand($min,$max);
        if(!in_array($random, $tal)){
           $nyttal = false;
           //sæt ind
        $tal[]=$random;
           //sortér
        sort($tal); 
        }
        print_r($tal);
    }
}
mix($tal);
