<?php

$arr = [10, 2, 3, 5, 7, 9, 1, 4, 8, 6];

function bubbleSort($arr) {
    $max = count($arr);
    $compare = 0;
    
    for ($i = 0; $i < $max; $i++) {
        for ($j = 0; $j < $max - 1; $j++) {
            $compare++;
            if ($arr[$j] > $arr[$j + 1]) {

                swap($arr);
            }
        }
    }
    echo $compare;
    return $arr;
}

print_r($arr);

function swap($arr) {
    $temp = $arr[$j + 1];
    $arr[$j + 1] = $arr[$j];
    $arr[$j] = $temp;

    return $arr;
}
echo "before".'<br>'. implode(',', $arr).'<br>';
$sort = bubbleSort($arr);
echo '<br>'."after".'<br>'. implode(',',$sort);
