<?php
 $errormessage=['test','Du alleresde opret!','udfyld alle felter'];
 $error = 0;
 
if (filter_has_var(INPUT_GET, 'error')){
  $error = filter_input(INPUT_GET,'error',FILTER_SANITIZE_NUMBER_INT);
   
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        <link href="container.scss" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
        <title>Fælles Campus Valgfag 2022</title>
    </head>

    <body>

        <div class="container-sm">
            <!-- Content here -->

            <h1>"Fælles Campus 2022"</h1>
            <br><!-- comment -->
            <h2>Tilmelding for priod 2</h2>
<?php echo $errormessage[$error];?>
            <form method="post" action ="inserttest.php"class="row g-3">
                <div class="col-md-4">
                    <label for="validationServer01" class="form-label">First name</label>
                    <input type="text" class="form-control is-valid" name="elevnavn" id="validationServer01" value=" " required>
                    <div class="valid-feedback">
                        <br>
                    </div>
                </div>
                <div class="col-md-4">
                    <label for="validationServer02" class="form-label">Last name</label>
                    <input type="text" name="efternavn" class="form-control is-valid" id="validationServer02" value=" " required>
                    <div class="valid-feedback">

                    </div>
                </div>
                <br>
                <div class="col-md-5">
                    <label for="validationServerUsername" class="form-label">Uni- login</label>
                    <div class="input-group has-validation">

                        <input type="text" class="form-control is-invalid" id="validationServerUsername" aria-describedby="inputGroupPrepend3 validationServerUsernameFeedback" required>
                        <div id="validationServerUsernameFeedback" class="invalid-feedback">
                            Det er sammen din skolen log-in.
                        </div>
                    </div>
                </div>

                <div class="col-md-4">
                    <label for="validationServer05" class="form-label">Elev nr.</label>
                    <input type="text" name="nr" class="form-control is-invalid" id="validationServer05" aria-describedby="validationServer05Feedback" required>
                    <div id="validationServer05Feedback" class="invalid-feedback">
                        Dit elev fra skolen.
                    </div>
                </div>
                <div class "col-md-4">
                    <label>Hvilken indgang går du på?</label>
                    <select class="form-select form-select" name ="indgang" aria-label=".form-select">
                        <option selected>åbent valge her</option>
                        <option value="1">Mennesker, Livsstil og sundhed</option>
                        <option value="2">It , Netvæk og Design</option>
                        <option value="3">Digital 10</option>
                    </select>
                </div>
                <h2>Vælg dit fag</h2><!-- comment -->
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">FørstePrioritet</th>
                            <th scope="col">AndenPrioritet</th>
                            <th scope="col-md-4">Fag</th>

                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        <tr>
                            <th scope="row"><div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="first" id="inlineRadio1" value="1">

                                </div></th>
                            <th>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="second" id="inlineRadio2" value="1">

                                </div></th>

                            <td>Animation af forskellig art</td>

                        </tr>
                        <tr>
                            <th scope="row"><div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="first" id="inlineRadio1" value="2">

                                </div></th>
                            <th>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="second" id="inlineRadio2" value="2">

                                </div></th>

                            <td>Opelev verden</td>

                        </tr>
                        <tr>
                            <th scope="row"><div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="first" id="inlineRadio1" value="3">

                                </div></th>
                            <th>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="second" id="inlineRadio2" value="3">

                                </div></th>

                            <td>Fitness</td>
                        </tr>
                        <tr>
                            <th scope="row"><div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="first" id="inlineRadio1" value="4">

                                </div></th>
                            <th>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="second" id="inlineRadio2" value="4">

                                </div></th>

                            <td>"Stylisten" Kosmetiker</td>

                        </tr>
                        <tr>
                            <th scope="row"><div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="first" id="inlineRadio1" value="5">

                                </div></th>
                            <th>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="radio" name="second" id="inlineRadio2" value=" 45">

                                </div></th>

                            <td>"Strylisten" Frisør</td>

                        </tr>
                    </tbody>
                </table>     

                <div class="col-4"></div>

                <div class="col-12">
                    <input class="btn btn-primary" type="submit" value="Submit form">

                </div>


            </form>
        </div>
        <script>
            window.addEventListener('DOMContentLoaded', (event) => {
                let count = 0;
                const selectedSubject = {'first': 0, 'second': 0};
                const radios = document.querySelectorAll('input[type=radio]');
                radios.forEach(element => element.addEventListener('change', (event) => {
                        count++;
                        if (count > 4) {
                            alert('bestem dig nu snart. Du har allerede klikket ' + count + ' gange!');
                        }
                        if (event.target.name === 'first') {
                            selectedSubject.first = event.target.value;
                            if (selectedSubject.first === selectedSubject.second) {
                                //fjern placering af 2
                                let seconds = document.querySelectorAll('input[name=second]');
                                seconds.forEach((item) => {
                                    item.checked = false;
                                });
                                selectedSubject.second = 0;
                            }
                        }
                        if (event.target.name === 'second') {
                            selectedSubject.second = event.target.value;
                            if (selectedSubject.first === selectedSubject.second) {
                                let firsts = document.querySelectorAll('input[name=first]');
                                firsts.forEach((item) => {
                                    item.checked = false;
                                });
                                selectedSubject.first = 0;
                            }
                        }
                        console.log(selectedSubject);
                    }
                    ));
            });
        </script>
    </body>
</html>
