<?php

$sum = 0;
$arr = array(2, 3, 5, 7, 9, 11, 13, 17);
for ($i = 0; $i < 5; $i++) {
    if ($i % 2 == 0) {
        $sum = abs($i - $arr[$i]) - $sum;
    } else {
        $sum = $i - $arr[$i] + $sum;
    }
}
echo $sum;

