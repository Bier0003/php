<?php

$tal = [0, 3, 6, 7, 8, 11, 14, 16, 21];

/*function deletePos($tal) {

    echo $del = rand(0, 8);
    unset($tal[$del]);
    echo "<pre>";
    print_r($tal);
    echo "</pre>";
}*/
/**
 * 
 * @param type $tal
 * @param bool $deleteposition  tru, hvis position skal fjernes
 * @return array
 */
function delete($tal,$deleteposition=true) {
    echo $del = rand(0, 8);
    if(!$deleteposition){
    if (($key = array_search($del, $tal)) !== false) {
        unset($tal[$key]);
        echo "fjerner værdi, hvis den findes";
    }}
    else{
        unset($tal[$del]);
        echo "fjerner position";
    }
    echo "<pre>";
    print_r($tal);
    echo "</pre>";
    return $tal;
}

delete($tal,true);

function qvad($t,$fed){
    if($fed){
        return '<b>'.$t*$t.'</b>';
    }
    return $t*$t;
}

echo qvad(3,false);