<?php

$indeks = [10, 7, 4, 7, 12, 4, 2];

function arrayFunction($a) {
    //$var = '<table border = "2" style ="width:50%; height:50%" ><tbody><td>Array Index</td><td>Array Value</td></tr>';
    $arrayIndex = '';
    $arrrayValue = '';
    foreach ($a as $value) {

        $arrayIndex .= '<td>'. array_search($value, $a). '</td>';
        $arrrayValue .= '<td>' . mb_strtoupper($value). '</td>';
        //$var .= "<tr><td>" .array_search($value, $a). "</td><td>" . mb_strtoupper($value) . "</td></tr>";
    }
    //$var .= '</table>';
    $var = '<table border ="2"><tr><td>Array Index</td>'.$arrayIndex.'</tr><tr><td>Array Value</td>'.$arrrayValue.'</tr></table>';
    //var_dump($var);
    return $var;
}

echo arrayFunction($indeks);

function text($a) {
    $temp1 = $a[0];
    $temp2 = $a[2];
    
    $a[0] = $temp2;
    $a[2] = $temp1;
//shuffle($a);
    //print_r($a[0].$a[2]);
    return $a;
}

//text($indeks);
//$indeks = text($indeks);
echo "</br>".arrayFunction(text($indeks));