<?php

$mail = "bier@edu.sde.ze";

function landkode($mail) {
    $mailar = explode(".", $mail);

   return array_pop($mailar);
}

function identitetland($email) {
    $code = landkode($email);

    $file_content = file("extensions.txt");

    foreach ($file_content as $line) {
     
        $pos = strpos($line, '@');
       
        $sub = substr($line, 0, $pos);
     
        
         if($code==$sub){
             $ef = substr($line, $pos + 1);
             return $ef;
         }
         
    }
    return "not found";
  
}
echo identitetland($mail);

