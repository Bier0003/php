<?php
$serverName = 'localhost';
$userName = 'root';
$password = '';
$dbName ='valgfag';

   //create connection
$con = new mysqli($serverName, $userName,$password,$dbName);

if($con->error){
    echo 'Failed to connect!';
    exit();
}
//print_r($con);