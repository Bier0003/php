<?php

$indeks = [10, 7, 4, 7, 12, 4, 2];
/**
 * 
 * @param array $a
 * @return string en table
 */
function arrayFunction($a) {

    $arrayIndex = '';
    $arrrayValue = '';
    foreach ($a as $value) {

        $arrayIndex .= '<td>' . array_search($value, $a) . '</td>';
        $arrrayValue .= '<td>' . mb_strtoupper($value) . '</td>';
    }

    $var = '<table border ="2"><tr><td>Array Index</td>' . $arrayIndex . '</tr><tr><td>Array Value</td>' . $arrrayValue . '</tr></table>';

    return $var;
}

echo arrayFunction($indeks);
/**
 * 
 * @param array $a
 * @param int $pos2
 * @param int $pos
 * @return array hvor plads er byttet om
 */
function swap($a, $pos2, $pos) {

    $temp = $a[$pos2];
    $a[$pos2] = $a[$pos];
    $a[$pos] = $temp;
    return $a;
}

echo "</br>" . arrayFunction(swap($indeks,0,2));


