<?php
//fra internet til opg59
$arr  = [10, 2, 3, 5, 7, 9, 1, 4, 8, 6];

function bubbleSort( $arr ) {
  $length = count( $arr );
  $comparisons  = 0;

  for ( $i = 0; $i < $length; $i++ ) {
    for ( $j = 0; $j < $length - 1; $j++ ) {
      $comparisons++;

      if ( $arr[ $j ] > $arr[ $j + 1 ] ) {
        $tmp            = $arr[ $j + 1 ];
        $arr[ $j + 1 ]  = $arr[ $j ];
        $arr[ $j ]      = $tmp;
      } // end of if conditional

    } // end of inner for loop
  } // end of first for loop
  echo '<h4>' . $comparisons . ' Comparisons</h4>';
  return $arr;
} // end of bubbleSort()


echo '<strong>Before Sorting</strong><br>' . implode( ', ', $arr ) . '<br>';
$sorted = bubbleSort( $arr );
echo '<strong>After Sorting</strong><br>' . implode( ', ', $sorted );

