<?php

$tal = array(4, 3, 3, 3, 2, 5, 3, 3, 2, 3);
for ($i = 0; $i < sizeof($tal); $i++) {

    if ($i < sizeof($tal) - 2) {
        if ($tal[$i] == $tal[$i + 2]) {
            $tal[0] = $tal[0] + $tal[$i];
        }
    }
}
echo $tal[0];

