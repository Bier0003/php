<?php

//print_r($_POST);
//Array ( [elevnavn] => Pornpan [nr] => 34567 [indgang] => 2 [first] => 1 [second] => 2 )
$error = "";
if (filter_has_var(INPUT_POST, 'elevnavn') && !empty($_POST['elevnavn'])) {
    //print_r($_POST);
    $first = $_POST["first"];
    $second = $_POST["second"];
    $indgang = $_POST['indgang'];
    $fnavn = $_POST['elevnavn'];
    $enavn=$_POST["efternavn"];
    $navn = $fnavn. " ".$enavn;
    $nr = $_POST['nr'];
    try {
        require_once 'db_valgfag.php';
        
        $sql = "INSERT INTO elev (elevnr,navn,indgangid) VALUES ('$nr','$navn','$indgang')";
        $con->query($sql);
        $sql = "INSERT INTO tilmelding (elevid,firstid,secondid) VALUES ('$nr','$first','$second')";
        $con->query($sql);

          header('location:test.php?elevid=' . $elev);
    } catch (Exception $e) {
       $error = "?error=1&navn=et eller andet";
        //echo $e;
        
    }
} else {
 $error = "?error=2";
    
}
header('location:test.php' . $error);
