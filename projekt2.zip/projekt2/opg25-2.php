<?php

for ($i=1; $i< 10; $sum=0) {
     $sum =+$i.'<br>';
    
     
   $i++; 
     
    echo $sum;
}


