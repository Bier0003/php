<?php
$stags = "";
$halvpennies = "";
if ((filter_has_var(INPUT_GET, "submit"))) {



    if (!empty($_GET["stags"])) {
        $stags = $_GET["stags"];
        $halvpennies = $stags * (23520/210 );
    } elseif (!empty($_GET["halvpennies"])) {
        $halvpennies = filter_input(INPUT_GET,"halvpennies",FILTER_SANITIZE_NUMBER_INT);
        $stags = $halvpennies * (210 / 23520);
    }
}
?>
<html>
    <center>
        <head>
            MONEY
        </head>
        <form action = opg7.php method =" get">

        <label>STAGS</label><p><!-- comment -->
        <input type="number" name="stags" value= <?php echo $stags ?>><p>
            <label>HALVPENNIES</label><p>
        <input type="number" name="halvpennies" value = <?php echo $halvpennies ?> ><P>
        <input type="submit" name="submit" value="convert">
        </form><P>
    </center>

</html>

