<html>
    
    Velkommen  <?php echo $_GET["value1"]; ?>. <br>
    Der er  <?php echo strlen($_GET["value1"]); ?> 
 i dit navn og dit navn stavet bagfra er :   <?php echo strrev($_GET["value1"]);?>.<br>
 <br>
 
 Om 5 år er du <?php echo $_GET ["value2"]+5 ;?> år gammel.
         
</html>
