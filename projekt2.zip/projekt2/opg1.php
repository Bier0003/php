<?php
//$myVar = 17;
//$myVar = 2;
//echo $myVar;

//$myName = 'Pornpan Madsen';
//echo $myName;

//$var1=17;
//$var2=9;
//$var3=$var1+$var2;
//echo $var3;

//$var1 = 'husk';
//$var2='at';
//echo  $var1.$var2;

//$minBY = 'Odense';
//echo strlen($minBY);


?>

