<?php

$sum = 0;
for ($i = 0; $i < 3; $i++) {
    for($j = 0;
    $j <= $i;
    j++) {
        $sum++;
    }
}
echo $sum;
?>