
<html>
    <head>
        <meta charset="UTF-8">
        <title>din fødselsdag</title>
    </head>
    <body>
    <center>
        <form action="15-1.php" method="get"/><p>
            din fødselsdag:<p>
       
     
            <input type='date' name='date2'/>
        <input name="submit" type ='submit'/><p>
                
        
  <?php     
        if(filter_has_var(INPUT_GET, 'submit')){
    
        $date = date_create($_GET['date2']);       
        echo date_format($date,"y/m/d");
        
 }      
        ?>
            
            
                </center>
    
</form>
    </body>
</html>
