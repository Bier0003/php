<html>
    <center>
        <head> Et cirkel area</head>
        <title>area</title>
        <body>
            <h2>Arealet</h2><p>
            <img src="cirkel.jpg" alt="pie" width="350" high="250"/>  <p>
                Radius(r) : 
            <input type="number" name="Radius" id="r" value="">cm<p>
                Diameter(d) :
            <input type="number" name="diameter" id="d" value="">cm<P>
                Area(A)  :
            <input type="number" name="area" id="a"value="">cm²<p>

            <div id="r2"></div>
            <div id="r3"></div>
         

                <script>
                    const r = document.getElementById('r');
                    const d = document.getElementById('d');
                    const a = document.getElementById('a');
                    const r2 = document.getElementById('r2');

                    const p = document.getElementById('p');

                    d.addEventListener('change', (e) => {
                        r.value = d.value / 2;
                        a.value = r.value * r.value * Math.PI;
                        skrivResultat(r.value);
                    });

                    r.addEventListener('change', (e) => {
                        d.value = r.value * 2;
                        a.value = r.value * r.value * Math.PI;
                        
                        skrivResultat(r.value);
                    });

                    a.addEventListener('change', (e) => {
                        r.value = Math.sqrt(a.value / Math.PI);
                        d.value = r.value * 2;
                        skrivResultat(r.value);
                    });

                    function skrivResultat(r) {

                        let txt = "Cirkel Area =  π * r²= π *" + r + " *" + r + " cm²";
                        let num = Math.PI;

                        txt += " π  ≈ " + num; 
                        txt += " ≈  ";
                        txt += num.toFixed(2);
                        r2.innerHTML = txt;
                        
                        let txt2 = "d = 2*"+ r +" ="+ r +"*"+ r +"cm";
                        r3.innerHTML = txt;
                        
                    }
                   

                </script>
           
        </body>



    </center>

</html>

