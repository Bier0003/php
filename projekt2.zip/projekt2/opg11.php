<?php
$value = 10;
$i = 10;
$i += $value;
$i++ ;
echo $i;
