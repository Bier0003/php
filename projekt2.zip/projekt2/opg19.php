
        <?php
        define("MINDIG" , 18);
        $alder = 17;
        if ($alder != MINDIG){
            echo 'Alder er ikke 18 år ';
        }
        else{
            echo 'Alder er 18 år';
        }
        ?>
   
