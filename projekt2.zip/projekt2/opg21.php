<?php
$alder = 17;
if($alder ==18){
    echo 'ALder er 18 år';
    
}
else{
    echo 'Alder er ikke 18 år';
}
/* '
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */

