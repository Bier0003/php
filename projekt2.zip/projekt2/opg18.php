<html
    <head>
    <meta charset="UTF-8">
    <title>Find landsdel fra postnr. </title>
</head>
<body>
<center>
    <form action = opg18.php method= "get">
        Postnr :
        <input type = "number" name = 'postnr'   placeholder="tastedig ind postnr." ><p>

        <input type ="submit" value="Nulstil"><p>
    </form>

</body><!-- comment -->
</head><!-- comment -->

<?php
$postnr = filter_input(INPUT_GET, 'postnr', FILTER_SANITIZE_NUMBER_INT);
echo $postnr;
$postal = ['Sjælland', 'Fyn', 'Bornholm', 'Jylland'];
$alder = array('Sjælland' => 43.6, 'Fyn' => 44.5, 'Bornholm' => 47.9, 'Jylland' => 42.1,'ugyldig' =>'null');
$landsdel="";


if ($postnr >=1000 && $postnr <= 9993) {
    echo "Det er postal omkring Denmark";
    
    if ($postnr <= 3600 && $postnr >= 999) {
        $landsdel = "Sjælland";
    } elseif ($postnr <= 4999 && $postnr >=3800) {
        $landsdel ="Sjælland";
    } elseif ($postnr <=3799 && $postnr >= 3700) {
        $landsdel = "Bornholm";
    } elseif ($postnr <= 5999 && $postnr >= 5000) {
        $landsdel = "Fyn";
    } elseif ($postnr <= 9997 && $postnr >= 6000) {
       $landsdel ="Jylland";
    }
} else {
    
    $landsdel = "ugyldig";
}
?>


<p>
       Der postnr stå i  <?php echo $landsdel ?><p>
        og det landel er <?php echo $alder[$landsdel ] ?> år<p>
    </center>
</html>

