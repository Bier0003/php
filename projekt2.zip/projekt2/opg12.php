<?php 

$i= 2;
$j=3;
$k= $i + 4;
$i++;
echo $i+ $j * $k;
?>