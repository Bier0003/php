<?php
$error = "";
if (filter_has_var(INPUT_POST, 'tal') && !empty($_POST['tal'])) {
    //print_r($_POST);
    $tal = $_POST['tal'];
    $fag = $_POST['fag'];
    $elev = $_POST['elev'];
    try {
        require_once 'connect2.php';
       echo  $sql = "INSERT INTO karakter (elevid,fagid,karakter) VALUES ('$elev','$fag','$tal')";
        $con->query($sql);

 $con->insert_id;
    } catch (Exception $e) {
        $error = "?error=1";
    }
}
header('location:insert2.php'.$error);
