<?php
$serverName = 'localhost';
$userName = 'root';
$password = '';
$dbName ='karakterbog';

   //create connection
$con = new mysqli($serverName, $userName,$password,$dbName);

if($con->error){
    echo 'Failed to connect!';
    exit();
}