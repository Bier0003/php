<?php
//var_dump($_POST);

$number = $_POST['navn'];
$array_number = explode(' ', $number);
//var_dump($array_number);

$sum = 0;
foreach($array_number as $number){
    $sum += $number;
}
echo 'summen af indtaste to vilkårlige tal er: ' . $sum;
die;

echo $nr1 = " ";
echo "<hr>";
echo $pos = strpos($nr1, " ");
echo "<hr>";

if ($pos == true) {
    echo $tal1 = substr($nr1, 0, $pos);
    echo " + ";
    echo $tal2 = substr($nr1, $pos);
    echo " = ";
    echo $tal1 + $tal2;
} 
else {
    echo "nuber can't be found!";
}

echo $navn = $_POST["navn"];
echo "<hr>";
echo $pos = strpos($navn, " ");
echo "<hr>";

if ($pos == true) {
    echo "Hej  ";
    echo $tal1 = substr($navn, 0, $pos);
    echo "   Dit efternavn er";
    echo $tal2 = substr($navn, $pos);
}