<?php


$i= 0;

do{
    $sum += $i;
    echo $sum;
    
    $i++;
}

while ($i < 10);

    
    
  



