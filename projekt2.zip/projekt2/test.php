<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
          <center>
        <head>
            MONEY
        </head>
        <form action = opg7.php method =" get">

        <label>STAGS</label><p><!-- comment -->
        <input type="number" name="stags" id="stags" value="2"><p>
            <label>HALVPENNIES</label><p>
        <input type="number" name="halvpennies" id="halvpennies" value = "" ><P>
        <input type="submit" name="submit" id="submit" value="convert"> <P></form>
    </center>
    <script>
        const stags =document.getElementById('stags');
        const halvpennies=document.getElementById('halvpennies');
        const submit =document.getElementById('submit');
 submit.addEventListener('click',(e)=>{
     e.preventDefault();
     if(stags.value>0){
      halvpennies.value=stags.value*(23520/210);
  }
  else if(halvpennies.value>0){
      stags.value=halvpennies.value*(210/23520);
  }
      
 });
       
    //23520 / 210
    </script>
    </body>
</html>
