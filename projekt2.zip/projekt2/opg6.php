<form action ="opg6.php " method = "get">
    
    <label>værdi1 :</label>
    <input type = "number" name="et" value = "number1"/><br>
    
    <label>action :</label> 
    <select name="action">
<option value="+">plus</option>
<option value="-">minus</option>
<option value="*">multiply</option>
<option value="/">devide</option>
</select><br>
<label>værdi2 :</label> 
<input type = "number" name = "to" value = "number2"/><br>

<input type= "submit" value="submit" />

</form>

<?php 
if(filter_has_var(INPUT_GET,"et") &&!empty($_GET["to"]) &&!empty($_GET["et"])){
$resultet="";
$et = $_GET["et"];
$action = $_GET["action"] ;
$to = $_GET["to"];

if($action == "+"){
   $resultet = $et+$to;
}
 elseif($action == "-"){
    $resultet = $et-$to;
 }
 elseif($action == "*"){
      $resultet = $et*$to;
 }
 elseif($action == "/"){
     $resultet = $et/$to;
 }
echo $et;
echo $action ;
echo $to;

echo "=".$resultet ;
}
