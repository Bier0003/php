<?php
$i = 3;
$j= 7;
$k=4;

if (($i + $j)% $k==2 && $j<= 8)
{
   $i = $k + $j % 4;
}
else{
    $i = $i - $j % 5;
}
echo $i;


