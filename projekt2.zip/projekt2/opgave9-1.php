<?php
//
//$myfile =fopen( "navn.txt", "a") or die ("Unable to open file!");
// 
// echo $file = strpos($myfile," ");
// 
//if ($myfile ==true){
//    echo "dit navn er:"$navn = substr($file,0, $myfile,"\n");
//    echo " + ";
//    echo "Efternavn er:"$efternavn = substr($file, $myfile,"\n");
//    echo $navn + $efternavn ." Du er ind vores database" ;
//}
//    else{
//        echo "Desværre, Du er ikke ind i vores database";
//    }
//    
   
    
    
 //fclose($myfile);  
 $file_content = file_get_contents('navn.txt');
 echo $file_content;
 
 $exist_efternavn = strpos($file_content,'Madsen') ? true : false;
 
 
 var_dump($exist_efternavn);
    
    
   /* $myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
$txt = "John Doe\n";
fwrite($myfile, $txt);
$txt = "Jane Doe\n";
fwrite($myfile, $txt);
fclose($myfile);
    * 
    * $fp = fopen('data.txt', 'a');//opens file in append mode.
fwrite($fp, ' this is additional text ');
fwrite($fp, 'appending data');
fclose($fp);
    * 
    * $homepage = file_get_contents('http://www.example.com/');
echo $homepage;
    
  */
 

