
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        $i = 10;
        $i = 1;
        $i += 1;
        $i++;
        echo $i;
        
        
        
        ?>
    </body>
</html>
