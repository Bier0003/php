
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
    <center>
        <head>
            MONEY
        </head>


        <label>STAGS</label><p><!-- comment -->
        <input type="number" name="stags" id="stags" value=""><p>
            <label>HALVPENNIES</label><p>
        <input type="number" name="halvpennies" id="halvpennies" value = "" ><P>
        <p id="p"></p>
    </center>
    <script>
        const stags = document.getElementById('stags');
        const halvpennies = document.getElementById('halvpennies');
const p = document.getElementById('p');

        stags.addEventListener('change', (e) => {
           
            halvpennies.value = stags.value * (23520 / 210);
            p.textContent=halvpennies.value;
        });
        
        halvpennies.addEventListener('change', (e) => {
            stags.value = halvpennies.value * (210 / 23520);
            p.textContent=stags.value;
            
        });

        //23520 / 210
    </script>
</body>
</html>
