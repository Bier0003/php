<?php
$i= 3;
$j= 7;
$k = 4;
if ($i<=7 || $j >= 7 && $k % 2 == 1 ){
    $i += 2 + 5 *3;
    //echo "test: i=$i og j=$j<br>";
}
else{
    $i += 5- 2 / 3;
}
echo $i;



