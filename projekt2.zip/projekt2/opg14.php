<?php

$alder = rand(-100, 200);
echo $alder;
echo"<hr>";
if (130 < $alder || $alder < 0) {
    echo "ugyldig alder";
} elseif ($alder < 18) {
    echo"du får ungdomsrabat";
} elseif ( $alder <= 65) {
    echo 'Du får ingen rabat';
} else {
    echo 'Du får pensionistrabat';
}
