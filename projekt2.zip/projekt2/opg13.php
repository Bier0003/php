<?php

$alder = 16;
if ($alder > 17) {
    echo "Du har stemmeret, hvis alderen er over 17";
}
elseif ($alder == 17){
echo 'Du har stemmeret om et år';
} 
else{
    echo "Du har ikke stemmeret hvis man under 18";
}
?>
