
<form action= "opg1_side2.php" method = "get">
    ditnavn: <input type="text" name ="value1" />
    <br><br><br>
   Alder: <input type="number" name="value2" />
   <br>
    <input type="submit"/>
    
    
    
    
    
    
    
    
    
    
</form>