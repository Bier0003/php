
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="opg9.php" method='post'>
            <input type='submit' >
            <input type ='text' name = 'navn'>

        </form>
    </body>
</html>
