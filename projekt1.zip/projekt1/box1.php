<?php
if (filter_has_var(INPUT_GET, 'error')) {
    $error = [1 => 'filter ikke udfyld', 2 => 'der er allerede give karakter fag'];
    if (array_key_exists($_GET['error'],$error)) {
        echo $error[$_GET['error']];
    }
}
require_once 'connectbox.php';
$sql = "SELECT elevid, count(karakter) AS antal,"
        . " sum(karakter) AS ialt, MAX(karakter) AS maks,"
        . " MIN(karakter) AS mindst,"
        . "avg(karakter) AS gennemsnit"
        . " from karakter GROUP BY elevid;";

$result = $con->query($sql);
$average = [];
while ($row = $result->fetch_object()) {
    $average[$row->elevid]['mindst'] = $row->mindst;
    $average[$row->elevid]['maks'] = $row->maks;
    $average[$row->elevid]['gennemsnit'] = $row->gennemsnit;
}

$sql_karakter = "SELECT elev.ID, navn, karakter, fag"
        . " FROM elev "
        . "JOIN karakter ON elev.ID = elevid "
        . "JOIN fag ON fagid= fag.ID "
        . "ORDER BY elev.ID";
$sql_elev = "SELECT ID,navn FROM elev";
$result_k = $con->query($sql_karakter);
$result_elev = $con->query($sql_elev);
$option = '';
$elev = [];
//$html_1=''
while ($row = $result_elev->fetch_object()) {
    $option .= "<option value=$row->ID>$row->navn</option>";
    $elev[$row->ID] = $row->navn;

//$html_1.="<tr><td>$row->fag</td><td>$row->karakter</td></tr>";
}
$info = [];
while ($row = $result_k->fetch_object()) {
    $info[$row->ID][$row->fag] = $row->karakter;
}

//$average = array_sum($tal)/count($tal); 
?>

<!DOCTYPE html>
<html>
    <center>
        <br><br><br>
        <head> KARAKTERBOG <br><br><br>
        <meta charset="UTF-8">
        <title>KARAKTERBOG</title>
        <style>
            p,td{
                text-align:center;
            }
            table, th, td{
                border: 1px solid red;
            }
            table {
                width: 500px;
                margin: auto
            }
        </style>
    </head>
    <body>

        <form method="post" action ="insertbox1.php"> 

            <label> navn:</label>
            <select name='elev'>
                <?php echo $option ?>
                <?php
                foreach ($elev as $ID => $navn) {
                    echo "<option value = $ID>$navn</option>";
                }
                ?>
            </select>
            <br>
            <label>Fag:</label>
            <select name='fag'>
                <option value=1>Matermatik</option>
                <option value=2>Datateknik</option>
                <option value=3>Dansk</option>
                <option value=4>Engelsk</option>

            </select><br>

            <label>Karakter:</label>
            <select name='tal'>
                <option>0</option>
                <option>2</option>
                <option>4</option>
                <option>7</option>
                <option>10</option>
                <option>12</option>
            </select><br><br>

            <input type = 'submit' value ='GEM' ><br><br>
            </center>
        </form>


    </body>

</html>


