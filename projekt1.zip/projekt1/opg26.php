<?php

$i = 0;
$mak = 10;
while ($i <= 10) {

    echo $sum = + $i;

    $i++;
}
