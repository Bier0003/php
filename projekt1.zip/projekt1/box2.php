<?php

require_once 'connectbox.php';
if (filter_has_var(INPUT_GET, 'elevid') && ( $elevid = filter_var($_GET['elevid'], FILTER_SANITIZE_NUMBER_INT) )) {
    

    $sql = "SELECT elevid ,count(karakter) AS antal,"
            . " sum(karakter) AS ialt, MAX(karakter) AS maks,"
            . " MIN(karakter) AS mindst,"
            . "avg(karakter) AS gennemsnit"
            . " from karakter WHERE elevid= $elevid;";

    $result = $con->query($sql);
    $average = [];
    while ($row = $result->fetch_object()) {
        $average['mindst'] = $row->mindst;
        $average['maks'] = $row->maks;
        $average['gennemsnit'] = $row->gennemsnit;
    }
}
$sql_karakter = "SELECT elev.ID, navn, karakter, fag"
        . " FROM elev "
        . "JOIN karakter ON elev.ID = elevid "
        . "JOIN fag ON fagid= fag.ID  "
        . "WHERE elevid= $elevid";

$result_k = $con->query($sql_karakter);



$info = [];
while ($row = $result_k->fetch_object()) {
    $info[$row->fag] = $row->karakter;    
    $navn=$row->navn;
}

//$average = array_sum($tal)/count($tal); 
?>
<!DOCTYPE html>
<html>
    <center>
        <br><br><br>
        <head> ELEV <br><br><br>
        <meta charset="UTF-8">
        <title>KARAKTERBOG</title>
        <style>
            p,td{
                text-align:center;
            }
            table, th, td{
                border: 1px solid red;
            }
            table {
                width: 500px;
                margin: auto
            }
        </style>
    </head>
    <body>

        <form action ="" method=  "POST"> 




</center>
</form>



    <table> 
        <tr>
            <td colspan='2'><?php echo $navn ?></td>
        </tr>
        <tr>

            <th>fag</th>
            <th>karakter</th>
        </tr>

        <?php
            foreach ($info as $fag => $karakter) {
                echo "<tr><td>$fag</td><td>$karakter</td></tr>";
            }
        
        ?>


        <tr>

            <th>Information</th>
            <th>karakter</th>
        </tr>

        <tr>

            <td>gennemsnit </td>
            <td><?php echo $average['gennemsnit']; ?> </td>
        </tr>
        <tr>

            <td>mindste    </td>
            <td><?php echo $average['mindst'] ?> </td>  
        </tr>
        <tr>

            <td>maks    </td>
            <td> <?php echo $average['maks'] ?></td>
        </tr>
    </table><br><br><br>
        <form>
            <center>
            <INPUT type = 'button' value ='tilbag' onclick="history.back(-1)"/>
            </center>
        </form>
        


</body>

</html>



