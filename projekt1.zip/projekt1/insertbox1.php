<?php

$error = "";
if (filter_has_var(INPUT_POST, 'elev') && !empty($_POST['elev'])) {
    //print_r($_POST);
    $tal = $_POST['tal'];
    $fag = $_POST['fag'];
    $elev = $_POST['elev'];
    try {
        require_once 'connectbox.php';
       $sql = "INSERT INTO karakter (elevid,fagid,karakter) VALUES ('$elev','$fag','$tal')";
        $con->query($sql);

        $con->insert_id;
        header('location:box2.php?elevid=' . $elev);
    } catch (Exception $e) {
        header('location:box1.php?error=2');
    }
} else {
 $error = "?error=1";
    header('location:box1.php' . $error);
}
