<?php

function tegnSignatur(){
    
$st= "<font size=\"1\">";

$st.= "This code is written by BIER";
$st.= htmlentities(chr(153), ENT_QUOTES, 'cp1252');
$st.="</font>";
return $st;
}

$ea = tegnSignatur();
?>
<?php
/*
function UdregnSum($value1, $value2){
$res = $value1+$value2;
echo "summen af de to tal er: $res";

//UdregnSum(3, 5);
echo '<p>';
 }
UdregnSum(20, 30);


function UdregnSum($value1, $value2)
{
$res = $value1 + $value2;
return $res;       
}
echo UdregnSum(50, -7) + UdregnSum(4,4);

?>
<html>
    
</html>