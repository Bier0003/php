<?php
$nr= [];
$value1 = rand(10,50);

$i =0;
while($i<10){
   $value2 =rand(0,100); 
    $nr[$i] = $value2;
    $i++;
}
//echo '<hr>';
print_r($nr);
echo '<hr>';
