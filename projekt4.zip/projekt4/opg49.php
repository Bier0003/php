<?php

$arr = array(321, 76,"hallo");
$ingredienser = ['æg','salat','kartofler'];

function arrayFunction($a) {
    $Var ='';
    foreach ($a as $value){
        $Var .= "<li>". mb_strtoupper($value)."</li>";
    }
    return $Var;
}
echo '<ul>';
echo arrayFunction($ingredienser);
echo '</ul>';

echo '<ol>';
echo arrayFunction(text($ingredienser));
echo '</ol>';
//echo $arr[0];


 function text($a){
    shuffle($a);
    return $a;
 }
 
print_r(text($arr));