<html>
    <head>
        <meta charset="UTF-8">
        <title>kamp</title>
    </head>
    <body>

    <center>
        <table border = "1" style ="width:50%; height:50%" >
            <tr>
                <th>Kamp</th>
                <th>resultat</th>
                <?php
                $h1 = ['hold1', 'hold2', 'hold3', 'hold4'];

                //$result = array($h1,$h2);
                $i = 0;
                ?>

                <?php
                while ($i < 4) {
                    $h = 0;
                    //$h = 1;

                    while ($h < 4) {
                        if ($i != $h) {
                            echo '<tr><td>' . $h1[$i] . "-" . $h1[$h] . '</td><td></td></tr>';
                        }
                        $h++;
                    }



                    $i++;
                }
                ?>
        </table>
    </center>
</body>
</html>
