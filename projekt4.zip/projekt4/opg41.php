<?php
$karakter = array(10, 7, 4, 7, 12, 4);

print_r($karakter);
//echo '<br>';


$average = array_sum($karakter)/ count($karakter);
       echo $average;
       echo '<br>';
  echo 'Minimums karakter er   '.min($karakter);   

