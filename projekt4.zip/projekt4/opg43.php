<?php
$a1= [];
$a2=[];
$value1 = rand(10,50);
$i =0;
while($i<$value1){
   $value2 =rand(0,100);  
    $a1[$i] = $value2;
    
   if($value2%2==0){
          
       $a2[$i]= $value2;
      
   }

     $i++;
}

echo '<pre>';
print_r($a1);
echo '<hr>';
print_r($a2);
echo '</pre>';
foreach($a2 as $even){
    echo $even.'<br>';
}
