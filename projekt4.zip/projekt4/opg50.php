<?php
$arr = array(321,4,35);
function arrayFunction($a)
{
$a[0] = 1;		
}
arrayFunction($arr);
 echo $arr[1];

