<?php

$file_content = file_get_contents('navneliste.txt');
 echo $file_content;
 
 $exist_efternavn = strpos($file_content,'Nielsen') ? true : false;
 
 
 var_dump($exist_efternavn);
    



    
    
    
    
    
    






