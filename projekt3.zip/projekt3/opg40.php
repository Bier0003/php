<?php

$karakter = array(10, 7, 4, 7, 12, 4);

print_r($karakter);
//echo '<br>';

$max = sizeof($karakter);
for ($i = 0; $i < $max; $i++) {
    echo $karakter[$i] . "<br>";
}

$average = array_sum($karakter)/ count($karakter);
       echo $average;
       ;
    
 