<?php
$sum = 0;
for ($i =3; $i>0; $i --)
{
    if ($i + 3 % 2*2==3)
    {
        $sum = $sum +2;
        
    }
 else 
 {
 $sum++;       
    }
}
echo $sum;



