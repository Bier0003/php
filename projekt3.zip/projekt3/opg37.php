<?php
$sum= 0;
$j= 5;
$i=0;
while($i !=$j)
{
    
    $sum =$i++ + $j;
}
echo $sum;
?>