<?php
$sum = 0;
for ($i=0; $i<3; $i++)
{
    for($j=0; $j<=$i; $j++)
    {
        if ($sum+2 % 2 == 0)
        {
            $i = $sum +2;
        }
        $sum;
    }
}
echo $sum;
?>

