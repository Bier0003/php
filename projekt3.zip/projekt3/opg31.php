<?php
$sum = 0;
for ($i = 0;$i<3;$j++)
{
for ($i=0; $j<=$i; $j++)
{
    $sum++;
    if ($sum % 3 == 0)
    {
        $sum = $sum + $i;
    }
}
}
echo $sum;
?>