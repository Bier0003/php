<?php

$myfile = "price.csv";
$nyfile = "prislist.csv";

if (file_exists($myfile)) {
    //åbent file kun læser
    $file = new SplFileObject($myfile, 'r');

    $file2 = new SplFileObject($nyfile, 'w');
    //print_r($file);
    while (!$file->eof()) {
        $linenr = $file->key();

        // get the current line
        $line = $file->fgets();
        $line_a = explode(';', $line);
        if ($linenr == 0) {
            $line_a[3] = 'kostpris DKK';
        }else{
            $line_a[1] = str_replace(['black', 'Black'], 'sort', $line_a[1]);

            $line_a[3] = number_format(7.4 * omregn($line_a[3]), 2, ",") . ' dkk';
            /* while($nypris =$pris*7.4){

              number_format(float $num,
              int $decimal = 2,
              ?string $decimal_separator ='.',
              ?string $thusands_separator = ','
              );
              echo $pris;
              }
             */
        }

        debug($line_a);
        
        $nyline = join(";",$line_a);
        $file2->fwrite($nyline);
    }
}


/* >
 * $file_handler = fopen($my
 * file, "w");
  echo fread($file_handler, filesize($myfile));
  if ($file_handler == true) {
  fwrite($file_handler, $myfile);
  }
  fclose($file_handler);
 */ else {
    echo "File does not exist.";
}

function debug($obj) {
    echo'<pre>';
    print_r($obj);
    echo '</pre>';
}

function omregn($string) {
    $pos = strpos($string, ' ');

    $pris = substr($string, 0, $pos);

    $nypris = str_replace(',', '.', $pris);
    $tal = filter_var($nypris, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
    return (float) $tal;
}
