<?php

$i = 6;
$sum = 0;
while ($i > 3) 
{
    for ($j = 2; $j < 5; $j++) 
    {
        if ($j != $i) 
        {
            $sum = $sum + $i - $j;
        }
            else
            {
            $i--;
            $sum--;
            }
    }
$i--;
}
echo $sum;