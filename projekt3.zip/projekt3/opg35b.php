<?php

$maks = 10;
$i = 0;
$sum = 0;

while ($i <= $maks) {
    //$sum += $i;
    /* for ($j = 1; $j <= $i; $j++) {
      echo $j .' ';
      } */

    //echo '$i er ' . $i . ' ';
    $j = 1;
    while ($j <= $i) {
        $k=1;
        while($k <= $j){
            echo $k;
            $k++;
            
        }
        //echo $j;
        $j++;
        echo '<br>';
    }
    

    $i++;
    echo '<br>';
}

