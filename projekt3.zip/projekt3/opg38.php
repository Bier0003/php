<?php
$sum = 0;
$j=1;
$i= 0 ;
while($i<$j || $j > $sum)
{

   $sum =$i++ + $j++;
   if($j % 2 !=0)
   {
       $i = $sum +$i;
          
   }
   
}
echo $sum;
